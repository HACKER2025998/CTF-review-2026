def hash256(data):
    return sha256(data).digest()

def merge_nodes(a, b):
    return hash256(a + b)

def gen_test(is_true):
    a = hash256(os.urandom(8))
    b = hash256(os.urandom(8))
    c = hash256(os.urandom(8))
    d = hash256(os.urandom(8))
    bias = b"" if is_true else os.urandom(8)
    left = merge_nodes(a, b + bias)
    right = merge_nodes(c, d)
    root = merge_nodes(left, right)
    return a.hex(), b.hex(), c.hex(), d.hex(), root.hex()

def generate(flag_bytes, output_file="output.txt"):
    flag_int = int.from_bytes(flag_bytes, byteorder='big')
    flag_binary = bin(flag_int)[2:]
    challenges = []
    for i, bit in enumerate(flag_binary):
        bit_int = int(bit)
        a, b, c, d, root = gen_test(bit_int)
        challenges.append([a, b, c, d, root])
