#!/usr/bin/env bash
set -u
printf '%s\n' 'NCTF26 | vérification locale non intrusive' '----------------------------------------'
for tool in python3 git curl jq file strings xxd unzip 7z ncat nmap wg openssl gdb binwalk tshark exiftool tmux hashcat ghidraRun sage; do
  if command -v "$tool" >/dev/null 2>&1; then
    printf '[OK]  %-14s %s\n' "$tool" "$(command -v "$tool")"
  else
    printf '[--]  %-14s %s\n' "$tool" 'non détecté (éventuellement facultatif)'
  fi
done
printf '\nModules Python depuis interpréteur actif :\n'
python3 - <<'PY'
import importlib.util
for module in ('pwn','Crypto','requests','sympy','z3','numpy','PIL'):
    print(('[OK]' if importlib.util.find_spec(module) else '[--]'), module)
PY
printf '\nNe partage pas tes fichiers WireGuard ni les jetons KOTH.\n'
