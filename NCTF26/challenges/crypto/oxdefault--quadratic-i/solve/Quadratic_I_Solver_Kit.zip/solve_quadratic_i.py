#!/usr/bin/env python3
"""NCTF26 Quadratic I: builds SMT-LIB2, uses Z3 native lib via ctypes, verifies AES-256-GCM."""
import re, pathlib, hashlib, ctypes, sys, time
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import argparse
argparser=argparse.ArgumentParser()
argparser.add_argument('--timeout-ms',type=int,default=900000,help='Z3 search timeout in milliseconds (default 900000)')
args=argparser.parse_args()

HERE=pathlib.Path(__file__).parent
system=HERE/'system(2).txt'
vault=HERE/'vault(2).txt'
lines=[line.strip() for line in system.read_text().splitlines() if line.strip() and not line.startswith('#')]
assert len(lines)==81, len(lines)
terms=[]
for ln in lines:
    clause=[]
    for raw in ln.split('+'):
        raw=raw.strip()
        if raw=='1': clause.append(())
        elif re.fullmatch(r'x\d+', raw):
            j=int(raw[1:]); assert j<57;clause.append((j,))
        elif re.fullmatch(r'x\d+\*x\d+',raw):
            a,b=[int(v[1:]) for v in raw.split('*')]; assert 0<=a<b<57; clause.append((a,b))
        else: raise ValueError(raw)
    terms.append(clause)

# emit SMT-LIB2
header=['(set-option :produce-models true)',f'(set-option :timeout {args.timeout_ms})','(set-logic QF_UF)']
header += [f'(declare-fun x{i} () Bool)' for i in range(57)]
products=sorted({t for clause in terms for t in clause if len(t)==2})
header += [f'(define-fun y{a}_{b} () Bool (and x{a} x{b}))' for a,b in products]
for clause in terms:
    args=['true' if not t else (f'x{t[0]}' if len(t)==1 else f'y{t[0]}_{t[1]}') for t in clause]
    header.append('(assert (not (xor '+ ' '.join(args) + ')))')
header += ['(check-sat)', '(get-value ('+' '.join('x'+str(j) for j in range(57))+'))']
smt='\n'.join(header)+'\n'
(HERE/'quadratic_i.smt2').write_text(smt)
print(f'{len(lines)} quadratic equations, {len(products)} distinct quadratic monomials, SMT size {len(smt)} bytes',flush=True)

# Low-level z3 C API. Reason: libz3 present but z3-solver wheel not installed.
lib=ctypes.CDLL('libz3.so.4')
lib.Z3_mk_config.restype=ctypes.c_void_p
lib.Z3_mk_context.argtypes=[ctypes.c_void_p];lib.Z3_mk_context.restype=ctypes.c_void_p
lib.Z3_eval_smtlib2_string.argtypes=[ctypes.c_void_p,ctypes.c_char_p];lib.Z3_eval_smtlib2_string.restype=ctypes.c_char_p
lib.Z3_del_context.argtypes=[ctypes.c_void_p]
lib.Z3_del_config.argtypes=[ctypes.c_void_p]
cfg=lib.Z3_mk_config();ctx=lib.Z3_mk_context(cfg);lib.Z3_del_config(cfg)
print(f'Running local Z3 SMT solver ({args.timeout_ms/1000:g}s timeout)...', flush=True)
t0=time.time()
try:
    result=lib.Z3_eval_smtlib2_string(ctx,smt.encode()).decode(errors='replace')
finally:
    lib.Z3_del_context(ctx)
print(f'Z3 elapsed {time.time()-t0:.1f}s; result {result[:1000]}', flush=True)
if not result.startswith('sat'):
    print('NO VERIFIED SOLUTION: Z3 returned unsat or unknown; do not submit a guessed flag.')
    sys.exit(2)
values={int(i): (v=='true') for i,v in re.findall(r'\(x(\d+)\s+(true|false)\)',result)}
if len(values)!=57:
    raise RuntimeError('Could not parse 57 values from '+result)
vector=[int(values[i]) for i in range(57)]
for i,clause in enumerate(terms):
    check=0
    for t in clause:
        if not t: check^=1
        elif len(t)==1:check^=vector[t[0]]
        else:check ^= vector[t[0]]&vector[t[1]]
    if check: raise ValueError(f'equation {i} failed')
print('All 81 equations verified',flush=True)

# Possible byte alignments for 57 bits
bitstr=''.join(str(v) for v in vector)
bytelists=[]
bytelists.append(('MSB-pad-right',int(bitstr+'0'*7,2).to_bytes(8,'big')))
bytelists.append(('MSB-pad-left',int(bitstr,2).to_bytes(8,'big')))
bytelists.append(('LSB-pad-left',sum(v<<i for i,v in enumerate(vector)).to_bytes(8,'big')))
nonce=bytes.fromhex(re.search('nonce\\s*=\\s*([0-9a-f]+)',vault.read_text()).group(1))
ct=bytes.fromhex(re.search('ciphertext\\s*=\\s*([0-9a-f]+)',vault.read_text()).group(1))
for nm, bytes_ in bytelists:
    key=hashlib.sha256(bytes_).digest()
    try:
        pt=AESGCM(key).decrypt(nonce,ct,None)
        print('SUCCESS',nm, repr(pt),flush=True)
    except Exception as exc:
        print('GCM tag mismatch',nm,flush=True)
print('Recovered bits:',bitstr)
