NCTF26 - oxdefault--quadratic-i (500 points)

Challenge data:
- system(2).txt: 81 Boolean quadratic equations in x0..x56
- vault(2).txt: AES-256-GCM ciphertext; AES key SHA256(solution bits, MSB first)

A local 90-second Z3 attempt returned 'unknown', NOT a verified flag.

To reproduce and increase search budget:
  python3 -m pip install cryptography
  python3 solve_quadratic_i.py --timeout-ms 1800000

The solver uses the native libz3.so.4 (installed by libz3-4) through ctypes.
For Debian/Kali: sudo apt install -y libz3-4

Solver writes quadratic_i.smt2 (SMT-LIB2) in the same directory, which
can also be used with any compatible SMT solver supporting Boolean XOR.

A recovered solution is checked against all 81 equations and decrypted
with AES-GCM; the tool prints the recovered plaintext only if the
authentication tag verifies.

Warning: random-looking overdetermined quadratic systems can be very
hard. Increasing timeout does NOT guarantee a solution.
