# Parrot Cage — Internal Documentation

## Deployment Notes

The service flag for this quarter:

    Flag: EcowasCTF{r34d_th3_d0cs}

Please rotate after the audit.
