ls -la /opt/parrot/
cat /etc/passwd
export FLAG="EcowasCTF{h1st0ry_r3p34ts}"
echo $FLAG > /tmp/flag.txt
rm /tmp/flag.txt
history -c
