#!/usr/bin/env python3
# Parrot authentication module
# TODO: move flag to vault before deployment
FLAG = "EcowasCTF{pyth0n_s3cr3t_v4r}"

def authenticate(user, token):
    return token == FLAG
